package com.holyicey.holybota.mixin;

import com.holyicey.holybota.ModConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import vazkii.botania.common.entity.ManaSparkEntity;

@Mixin(value = ManaSparkEntity.class, remap = false)
public class SparkEntityMixin {
    // 可选：添加日志，便于验证注入是否生效
    private static final Logger LOGGER = LoggerFactory.getLogger(SparkEntityMixin.class);

    @ModifyConstant(
            method = "tick", // 核心修改：目标方法改为 tick（而非 registerTransfer）
            constant = @Constant(intValue = 1000), // 匹配类中 TRANSFER_RATE 常量值
            remap = false
    )
    private int modifyTransferRate(int original) {
        int customRate = ModConfig.getSparkTransferRate();
        // 可选：打印日志，确认数值替换结果
        LOGGER.debug("魔力火花传输速率已替换：原 1000 → 新 {}", customRate);
        return customRate;
    }
}

