package com.holyicey.holybota;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;

@Mod("holybota")
public class holybota {

    public holybota() {
        // 注册配置
        ModLoadingContext.get().registerConfig(net.minecraftforge.fml.config.ModConfig.Type.COMMON, ModConfig.SPEC, "holybota-common.toml");
    }
}

