package com.holyicey.holybota;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;

public class ModConfig {
    // 保留原有配置构建逻辑，但仅声明不提前调用.get()
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue SPARK_TRANSFER_RATE;
    public static final ForgeConfigSpec.BooleanValue ENABLE_SPARK_SPEED_OVERRIDE;

    // 静态代码块仅构建配置规范，不调用.get()（核心修复）
    static {
        BUILDER.push("Spark Settings");

        SPARK_TRANSFER_RATE = BUILDER
                .comment("魔力火花每tick的传输速度 (Mana/tick)",
                        "Botania 原版默认值: 1000",
                        "范围: 1 ~ 2100000000")
                .defineInRange("sparkTransferRate", 2100000000, 1, 2100000000);

        ENABLE_SPARK_SPEED_OVERRIDE = BUILDER
                .comment("启用火花速度覆盖",
                        "设置为 false 则使用 Botania 原版速度")
                .define("enableSparkSpeedOverride", true);

        BUILDER.pop();
        SPEC = BUILDER.build();
    }

    // 注册配置（时机由 Forge 控制，安全）
    public static void register() {
        ModLoadingContext.get().registerConfig(net.minecraftforge.fml.config.ModConfig.Type.COMMON, SPEC, "tconbota-common.toml");
    }

    /**
     * 安全获取传输速率（核心修复：添加配置加载检查）
     * @return 配置值（未加载时返回默认值 1000）
     */
    public static int getSparkTransferRate() {
        // 防御性检查：配置未加载 → 返回默认值
        if (!SPEC.isLoaded()) {
            return 1000;
        }

        if (!ENABLE_SPARK_SPEED_OVERRIDE.get()) {
            return 1000;
        }
        return SPARK_TRANSFER_RATE.get();
    }

    // 可选：暴露开关的安全获取方法（若其他地方需要用）
    public static boolean isSparkSpeedOverrideEnabled() {
        if (!SPEC.isLoaded()) {
            return true; // 未加载时默认启用
        }
        return ENABLE_SPARK_SPEED_OVERRIDE.get();
    }
}
// ... existing code ...